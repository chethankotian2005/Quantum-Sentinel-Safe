Packetizer
==========

.. automodule:: paramiko.packet
