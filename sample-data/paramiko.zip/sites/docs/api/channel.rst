Channel
=======

.. automodule:: paramiko.channel
